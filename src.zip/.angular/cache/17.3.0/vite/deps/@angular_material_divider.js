import {
  MatDivider,
  MatDividerModule
} from "./chunk-B43267QM.js";
import "./chunk-JW4UNJVR.js";
import "./chunk-Z2IJK5TB.js";
import "./chunk-TL65QNLR.js";
import "./chunk-UB4ESSJA.js";
import "./chunk-Z45VEKDQ.js";
import "./chunk-PDN7TZRU.js";
import "./chunk-ASLTLD6L.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
