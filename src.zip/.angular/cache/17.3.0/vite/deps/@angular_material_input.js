import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-SXEWF5MM.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-A56FVS7T.js";
import "./chunk-D7NBXG2O.js";
import "./chunk-WHWDOGSH.js";
import "./chunk-JW4UNJVR.js";
import "./chunk-Z2IJK5TB.js";
import "./chunk-TL65QNLR.js";
import "./chunk-UB4ESSJA.js";
import "./chunk-Z45VEKDQ.js";
import "./chunk-PDN7TZRU.js";
import "./chunk-ASLTLD6L.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
