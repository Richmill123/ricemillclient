import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-UC3MC3S5.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-6MJ44TGY.js";
import "./chunk-RA2GA3LK.js";
import "./chunk-DPUB53AQ.js";
import "./chunk-QFR4LTCW.js";
import "./chunk-VQNCUITB.js";
import "./chunk-CHWZ6B6T.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-XZV5GI3Z.js";
import "./chunk-OMHX4UE6.js";
import "./chunk-NUPWKT2N.js";
import "./chunk-UB4ESSJA.js";
import "./chunk-Z45VEKDQ.js";
import "./chunk-PDN7TZRU.js";
import "./chunk-J4B6MK7R.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
