import {
  MatDivider,
  MatDividerModule
} from "./chunk-DL7JKC6G.js";
import "./chunk-XZV5GI3Z.js";
import "./chunk-OMHX4UE6.js";
import "./chunk-NUPWKT2N.js";
import "./chunk-UB4ESSJA.js";
import "./chunk-Z45VEKDQ.js";
import "./chunk-PDN7TZRU.js";
import "./chunk-J4B6MK7R.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
