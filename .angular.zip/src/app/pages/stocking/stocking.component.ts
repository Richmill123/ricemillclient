import { Component } from '@angular/core';

@Component({
  selector: 'app-stocking',
  standalone: true,
  imports: [],
  templateUrl: './stocking.component.html',
  styleUrls: ['./stocking.component.scss']
})
export class StockingComponent {

}
