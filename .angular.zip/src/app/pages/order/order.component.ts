import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ColDef, GridReadyEvent, GridApi, ICellRendererParams, ModuleRegistry } from 'ag-grid-community';
import { AgGridModule } from 'ag-grid-angular';
import { AllCommunityModule } from 'ag-grid-community';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { OrderFormDialogComponent } from './order-form-dialog/order-form-dialog.component';

// Register AG Grid modules
ModuleRegistry.registerModules([AllCommunityModule]);

interface Order {
  _id: string;
  clientId: string;
  name: string;
  villageName: string;
  address: string;
  phoneNumber: string;
  numberOfBags: number;
  totalAmount: number;
  advanceAmount: number;
  typeOfPaddy: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

@Component({
  selector: 'app-order',
  standalone: true,
  imports: [
    AgGridModule, 
    CommonModule, 
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule
  ],
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {
  private gridApi!: GridApi;
  
  // Column Definitions
  public columnDefs: ColDef[] = [
    { 
      field: 'name', 
      headerName: 'Name', 
      filter: true,
      sortable: true,
      resizable: true
    },
    { 
      field: 'villageName', 
      headerName: 'Village', 
      filter: true,
      sortable: true,
      resizable: true
    },
    { 
      field: 'phoneNumber', 
      headerName: 'Phone', 
      filter: true,
      sortable: true,
      resizable: true
    },
    { 
      field: 'typeOfPaddy', 
      headerName: 'Paddy Type', 
      filter: true,
      sortable: true,
      resizable: true
    },
    { 
      field: 'numberOfBags', 
      headerName: 'Bags', 
      filter: 'agNumberColumnFilter',
      sortable: true,
      resizable: true
    },
    { 
      field: 'totalAmount', 
      headerName: 'Total Amount', 
      filter: 'agNumberColumnFilter', 
      valueFormatter: this.currencyFormatter,
      sortable: true,
      resizable: true
    },
    { 
      field: 'advanceAmount', 
      headerName: 'Advance', 
      filter: 'agNumberColumnFilter', 
      valueFormatter: this.currencyFormatter,
      sortable: true,
      resizable: true
    },
    { 
      field: 'status', 
      headerName: 'Status', 
      filter: true, 
      cellStyle: this.statusCellStyle,
      sortable: true,
      resizable: true
    },
    this.createActionColumn()
  ];

  // Default Column Definitions
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 100,
    sortable: true,
    filter: true,
    resizable: true,
    floatingFilter: false,
    suppressMovable: true
  };

  // Data that gets displayed in the grid
  public rowData: Order[] = [];
  public loading = false;
  public searchText = '';
  public apiUrl = 'https://richmill.onrender.com/api/orders';
  public clientId = JSON.parse(sessionStorage.getItem('user') || '');

  constructor(
    private http: HttpClient,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  // Load orders from API
  loadOrders(): void {
    this.loading = true;
    const url = `${this.apiUrl}?clientId=${this.clientId}`;
    
    this.http.get<Order[]>(url).subscribe({
      next: (data) => {
        this.rowData = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading orders:', error);
        this.loading = false;
      }
    });
  }

  addNewOrder(): void {
    const dialogRef = this.dialog.open(OrderFormDialogComponent, {
      width: '800px',
      maxWidth: '95vw',
      disableClose: true,
      autoFocus: false,
      data: { isEdit: false }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccess('Order created successfully!');
        this.loadOrders();
      }
    });
  }

  private showSuccess(message: string): void {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      panelClass: ['success-snackbar']
    });
  }

  // Format currency values
  currencyFormatter(params: any): string {
    return '₹' + params.value.toLocaleString('en-IN');
  }

  // Style status cells based on their value
  statusCellStyle(params: any): any {
    if (params.value === 'COMPLETED') {
      return { color: 'green', 'font-weight': 'bold' };
    } else if (params.value === 'CANCELLED') {
      return { color: 'red', 'font-weight': 'bold' };
    }
    return { 'font-weight': 'bold' };
  }

  // Action column definition
  private createActionColumn(): ColDef {
    return {
      headerName: 'Actions',
      field: 'actions',
      width: 120,
      sortable: false,
      filter: false,
      cellRenderer: (params: ICellRendererParams) => {
        const wrapper = document.createElement('div');
        wrapper.className = 'd-flex gap-2';
        
        const editBtn = document.createElement('button');
        editBtn.className = 'btn btn-sm btn-outline-primary';
        editBtn.innerHTML = '<i class="fas fa-edit"></i>';
        editBtn.title = 'Edit';
        editBtn.onclick = (e: MouseEvent) => {
          e.stopPropagation();
          this.editOrder(params.data);
        };
        
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn btn-sm btn-outline-danger';
        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
        deleteBtn.title = 'Delete';
        deleteBtn.onclick = (e: MouseEvent) => {
          e.stopPropagation();
          this.deleteOrder(params.data);
        };
        
        wrapper.appendChild(editBtn);
        wrapper.appendChild(deleteBtn);
        
        return wrapper;
      }
    };
  }

  // Grid ready event
  onGridReady(params: GridReadyEvent): void {
    this.gridApi = params.api;
    
    // Auto-size all columns to fit the grid width
    this.gridApi.sizeColumnsToFit();
    
    // Add event listener for action buttons
    this.gridApi.addEventListener('cellClicked', (event: any) => {
      const target = event.event?.target as HTMLElement;
      const button = target?.closest('.action-btn');
      
      if (button) {
        const action = button.getAttribute('data-action');
        const id = button.getAttribute('data-id');
        
        if (action && id) {
          event.event.preventDefault();
          event.event.stopPropagation();
          
          if (action === 'edit') {
            const order = this.rowData.find(o => o._id === id);
            if (order) {
              this.editOrder(order);
            }
          } else if (action === 'delete') {
            const order = this.rowData.find(o => o._id === id);
            if (order) {
              this.deleteOrder(order);
            }
          }
        }
      }
    });
    
    // Handle window resize
    const gridDiv = document.querySelector('.ag-theme-alpine');
    if (gridDiv) {
      const resizeObserver = new ResizeObserver(() => {
        setTimeout(() => this.gridApi.sizeColumnsToFit());
      });
      resizeObserver.observe(gridDiv);
    }
  }
  
  // Handle search
  onSearch(): void {
    if (this.gridApi) {
      this.gridApi.setGridOption('quickFilterText', this.searchText);
    }
  }
  
  // Clear search
  clearSearch(): void {
    this.searchText = '';
    if (this.gridApi) {
      this.gridApi.setGridOption('quickFilterText', '');
    }
  }

  // Edit order
  editOrder(order: Order): void {
    const dialogRef = this.dialog.open(OrderFormDialogComponent, {
      width: '800px',
      maxWidth: '95vw',
      disableClose: true,
      autoFocus: false,
      data: { 
        isEdit: true,
        orderData: order
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showSuccess('Order updated successfully!');
        this.loadOrders();
      }
    });
  }

  // Delete order
  private deleteOrder(order: Order): void {
    if (confirm(`Are you sure you want to delete order for ${order.name}?`)) {
      const deleteUrl = `${this.apiUrl}/${order._id}?clientId=${this.clientId}`;
      
      this.http.delete(deleteUrl).subscribe({
        next: () => {
          this.showSuccess('Order deleted successfully!');
          this.loadOrders();
        },
        error: (error) => {
          console.error('Error deleting order:', error);
          this.snackBar.open(
            error.error?.message || 'Failed to delete order. Please try again.',
            'Close',
            { duration: 5000, panelClass: ['error-snackbar'] }
          );
        }
      });
    }
  }
}