import { Component } from '@angular/core';

@Component({
  selector: 'app-wages',
  standalone: true,
  imports: [],
  templateUrl: './wages.component.html',
  styleUrl: './wages.component.scss'
})
export class WagesComponent {

}
